<?php
 session_start();
 extract($_POST);
 extract($_SESSION);
 
require('includes/config.php'); 	
	//echo $uid;
	if(isset($submit))
	{
	$query="insert into shipping_details(name,address,postal_code,city,state,phone,f_id) values('$name','$address','$pc','$city','$state','$phone','$uid')";
	
	$res=mysqli_query($conn,$query) or die("Can't Execute Query...");

	
	}
	$name = $_SESSION['unm'];

  $query="select * from cart where name='$name'";
		
			$res=mysqli_query($conn,$query) or die("Can't Execute Query...");

			$count=0;

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
		<?php
			include("includes/head.inc.php");
		?>
</head>

<body>
			<!-- start header -->
				<div id="header">
					<div id="menu">
						<?php
							include("includes/menu.inc.php");
						?>
					</div>
				</div>
				<div id="logo-wrap">
				<div id="logo">
						<?php
							include("includes/logo.inc.php");
						?>
				</div>
				</div>
				
			<!-- end header -->
			<!------------------------------->

			<font style="font-size:30px;margin-left:420px">Shipping Details</font>	
			<div class="container">
			<!-- freshdesignweb top bar -->
            <div class="freshdesignweb-top">
                <div class="clr"></div>
				
            </div><!--/ freshdesignweb top bar -->    
		
      <div  class="form">
    		<form id="contactform" method="post"> 
    			<p class="contact"><label for="name">Name</label></p> 
    			<input id="name" name="name" placeholder="First and last name" required="" tabindex="1" type="text"> 
    			 <p class="contact"><label for="email">Email</label></p> 
    			<input id="email" name="email" placeholder="Email Address...." required="" tabindex="1" type="text"> 
    			<p class="contact"><label for="address">Address</label></p> 
    			<textarea id="address" name="address" placeholder="Address" required="" cols="55" row="10"type="email"> </textarea>
                
                <p class="contact"><label for="username">Postal Code</label></p> 
    			<input id="pc" name="pc" placeholder="201001" required="" tabindex="2" type="text"> 
    			 
                <p class="contact"><label for="city">City</label></p> 
    			<input type="text" id="city" name="city" required="" placeholder="delhi"> 
                <p class="contact"><label for="state">State</label></p> 
    			<input type="text" id="state" name="state" required="" placeholder="delhi"> 
            <p class="contact"><label for="phone">Mobile phone</label></p> 
            <input id="phone" name="phone" placeholder="phone number" required="" type="text"> <br>
            <input class="buttom" name="submit" id="submit" tabindex="5" value="Confirm & Proceed" type="submit"> 	 
     </form> 

    <?php 
	   

		if(isset($_POST['submit'])) {
			require 'PHPMailerAutoload.php';
			require 'credential.php';

			$mail = new PHPMailer;

			 //$mail->SMTPDebug = 4;                               // Enable verbose debug output

			$mail->isSMTP();                                      // Set mailer to use SMTP
			$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
			$mail->SMTPAuth = true;                               // Enable SMTP authentication
			$mail->Username = EMAIL;                 // SMTP username
			$mail->Password = PASS;                           // SMTP password
			$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
			$mail->Port = 587;                                    // TCP port to connect to

			$mail->setFrom(EMAIL, 'The Bookstore');
			$mail->addAddress($_POST['email']);     // Add a recipient

			$mail->addReplyTo(EMAIL);
			// print_r($_FILES['file']); exit;
			// for ($i=0; $i < count($_FILES['file']['tmp_name']) ; $i++) { 
			// 	$mail->addAttachment($_FILES['file']['tmp_name'][$i], $_FILES['file']['name'][$i]);    // Optional name
			// }
			
			$mail->isHTML(true);                                  // Set email format to HTML

			$mail->Subject = $_POST['name'];
			$mail->Body = "
						<h2 align='center'>Thank you ".$name." for purchesing from Bookstore</h2>
						<hr>
			           <table width='100%' border='1'>
			           <thead align='left'>
						<th>Product Name</th>
						<th>Category</th>
						<th>Price</th>
						</thead> 
						";
			$t_price = 0;
			while($row=mysqli_fetch_assoc($res))
				{
						
					$bdy = "<tr>
								<td>".$row['bnm']."</td>
							  	<td>".$row['bcat']."</td>
							  	<td>".$row['brate']."</td>
							</tr>";
											
					
					$count++;	
					$mail->Body .= $bdy;
					$t_price += $row['brate'];
				}
			$mail->Body .= "</table><hr>"."<div style='float:left'><b>Total</b></div><hr>"."<div style='float:right'><b>".$t_price."/=</b></div><br><br>"."<b>Date: ".date('l jS \of F Y h:i:s A')."<br><p>Regards,<br>Arnob</p></b>";
			//$mail->AltBody = $_POST['address'];

			if(!$mail->send()) {
			    echo 'Message could not be sent.';
			    echo 'Mailer Error: ' . $mail->ErrorInfo;
			} else {
			    header("location:payment_details.php");
			}
		}
	 ?>
</div>      
</div>
</body>