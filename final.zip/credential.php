<?php 
	/*Update credentials*/
	define('EMAIL', 'skillerrtm@gmail.com');
	define('PASS', 'euparnabgen05rtm');
 ?>