<?php 
 session_start();
 extract($_POST);
 extract($_SESSION);
 
require('includes/config.php'); 	
	//echo $uid;


	if(isset($_GET['nm']) and isset($_GET['cat']) and isset($_GET['rate']))
	{
		//add item
		$_SESSION['cart'][] = array("nm"=>$_GET['nm'],"cat"=>$_GET['cat'],"rate"=>$_GET['rate'],"qty"=>"1");

			$name = $_SESSION['unm'];
		$id = $_GET['id'];
		$nm = $_GET['nm'];
		$cat = $_GET['cat'];
		$rate = $_GET['rate'];
	    $query="insert into cart(name,uid,bnm,bcat,brate) values('$name','$id','$nm','$cat','$rate')";
	 
	    $res=mysqli_query($conn,$query) or die("Can't Execute Query...");

	    header("location: viewcart.php");
	}
	else if(isset($_GET['id']))
	{
		//del a item
		$id = $_GET['id'];
		unset($_SESSION['cart'][$id]);
		header("location: viewcart.php");
	}
	else if(!empty($_POST))
	{
		//update qty
		foreach($_POST as $id=>$val)
		{
			$_SESSION['cart'][$id]['qty']=$val;
			header("location: viewcart.php");
		}
	}


?>